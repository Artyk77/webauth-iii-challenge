The server

- produces a token
- sends token to client
- verify and decode the token

The client

- stores the token
- sends token on every request <-- to automatically like cookies.

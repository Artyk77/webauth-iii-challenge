const math = require('./math.js');

test('it runs the tests', () => {
  // comparing actual to expected
  expect(true).toBe(true); // assertion
});

it('it compare objects', () => {
  // Arrange
  const expected = { name: 'Eli' };

  // Act: run the production code
  const actual = getName('Eli');

  // Assert
  expect(actual).toEqual(expected);
  expect(getName()).toEqual({});
});

it('adds two numbers', () => {
  expect(math.add(2, 2)).toBe(4);
  expect(math.add(-2, 2)).toBe(0);
});

function getName(name) {
  return { name };
}

// TDD: Test Driven Development
// TDD: Test Driven Design

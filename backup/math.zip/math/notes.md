# steps

- mkdir
- cd into directory
- git init
- npm init -y
- gitignore node (or npx gitignore node)
- npm i -D jest or yarn add jest --dev

Types

- unit testing: run in isolation, test one unit, super fast
- integration testing: several components/units at a time, slower
- end to end: slowest by far
